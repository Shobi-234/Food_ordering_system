<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Rise n' Dine</title>
    <link rel="stylesheet" href="homestyle.css">
</head>
<body>
    <div class="home">
        <div class="homeheader">
        <a href="register.php" class="btn">register</a>
        <div class="brand-banner">
            <h3>Rise n' Dine</h3>
        </div>
        <a href="signin.php" class="btn">login</a>
    </div>
    </div>
    
</body>
</html>